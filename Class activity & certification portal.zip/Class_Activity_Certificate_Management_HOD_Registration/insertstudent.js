const mongoose = require("mongoose");

const Student = require("./models/student");


mongoose
    .connect("mongodb://127.0.0.1:27017/certificate_portal")

    .then(async () => {

        console.log(
            "MongoDB connected"
        );


        const students = [];


        for (let i = 1; i <= 59; i++) {

            students.push({

                rollNumber: i,

                name: `Student ${i}`,

                department:
                    "B.Tech Information Technology",

                email:
                    `student${i}@college.com`
            });
        }


        // Remove old student records
        await Student.deleteMany({});


        // Insert 59 students
        await Student.insertMany(
            students
        );


        console.log(
            "59 students inserted successfully"
        );


        mongoose.connection.close();

    })

    .catch((error) => {

        console.log(
            "Database error:",
            error.message
        );
    });