# Class Activity & Certificate Management System

## Features

- Student registration
- Existing preloaded students can activate their account
- New students can register
- Student login with roll number + password
- Passwords are stored as bcrypt hashes
- Student sees only their own activities
- Student can add activities
- Student can upload PDF/JPG/JPEG/PNG certificates
- Student can view/download their certificates
- Student can delete only their own activity records
- HOD login
- HOD can view all students
- HOD can search students
- HOD can view student activities
- HOD can view/download certificates
- HOD is read-only

## Requirements

- Node.js
- MongoDB running locally
- A browser

## Setup

Open CMD in this project folder:

```cmd
npm install
node server.js
```

Then open:

```text
http://localhost:5000
```

## MongoDB

The project currently uses:

```text
mongodb://127.0.0.1:27017/certificate_systemDB
```

If your MongoDB connection is different, change it in:

```text
server.js
insertstudent.js
```

## Existing 59 students

The original project already contains 59 student records.

Do NOT run `insertstudent.js` again after students have registered.

That script intentionally deletes all Student documents before inserting the initial 59 records.

If the database is empty and you need to create the initial 59 records, run:

```cmd
node insertstudent.js
```

Then stop using the script for normal operation.

## Student registration

For an existing student such as roll number 25:

1. Open Student Registration.
2. Enter roll number 25.
3. Enter the student's actual name.
4. Enter email.
5. Create a password.
6. Login using roll number 25 + that password.

The existing student record is activated instead of creating a duplicate.

For a new roll number such as 60:

1. Register roll number 60.
2. The system creates a new student record.

## HOD login

Demo HOD credentials:

```text
Email:    hod@college.com
Password: hod12345
```

Change these values in:

```text
routes/authroutes.js
```

before using the application outside a classroom/demo environment.

## Important

Do not store real passwords in the Student collection. The application stores bcrypt password hashes.

The session secret in `server.js` should also be changed before deployment.

## Project structure

```text
MongoDB/
├── middleware/
│   └── auth.js
├── models/
│   ├── student.js
│   └── activity.js
├── routes/
│   ├── authroutes.js
│   ├── studentroutes.js
│   └── activityroutes.js
├── public/
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── student.html
│   ├── hod-login.html
│   ├── hod.html
│   ├── student-details.html
│   └── style.css
├── uploads/
├── insertstudent.js
├── server.js
├── package.json
└── README.md
```

## HOD Registration and Login

HOD accounts are now stored in the MongoDB `hods` collection.

1. Open `http://localhost:5000/hod-register.html`.
2. Register with HOD name, email and password.
3. Open HOD Login and sign in using the registered email and password.
4. The HOD dashboard is read-only for student activity records.

HOD passwords are stored as bcrypt hashes. The previous hardcoded demo HOD credentials are no longer used.
