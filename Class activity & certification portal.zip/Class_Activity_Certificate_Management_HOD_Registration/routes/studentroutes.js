const express = require("express");

const Student = require("../models/student");

const {
    requireStudent,
    requireHod
} = require("../middleware/auth");

const router = express.Router();

// HOD: get all students
router.get("/", requireHod, async (req, res) => {
    try {
        const students = await Student
            .find()
            .select("-passwordHash")
            .sort({ rollNumber: 1 });

        res.json(students);
    } catch (error) {
        res.status(500).json({
            message: "Error getting students.",
            error: error.message
        });
    }
});

// Student: get own profile
router.get("/me/profile", requireStudent, async (req, res) => {
    try {
        const student = await Student
            .findOne({
                rollNumber: req.session.user.rollNumber
            })
            .select("-passwordHash");

        if (!student) {
            return res.status(404).json({
                message: "Student profile not found."
            });
        }

        res.json(student);
    } catch (error) {
        res.status(500).json({
            message: "Error getting profile.",
            error: error.message
        });
    }
});

// HOD: get one student
router.get("/:rollNumber", requireHod, async (req, res) => {
    try {
        const student = await Student
            .findOne({
                rollNumber: Number(req.params.rollNumber)
            })
            .select("-passwordHash");

        if (!student) {
            return res.status(404).json({
                message: "Student not found."
            });
        }

        res.json(student);
    } catch (error) {
        res.status(500).json({
            message: "Error getting student.",
            error: error.message
        });
    }
});

module.exports = router;
