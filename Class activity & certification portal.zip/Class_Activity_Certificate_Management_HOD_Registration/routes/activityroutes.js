const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const Activity = require("../models/activity");

const {
    requireStudent,
    requireHod
} = require("../middleware/auth");

const router = express.Router();

const uploadsDirectory = path.join(__dirname, "..", "uploads");

if (!fs.existsSync(uploadsDirectory)) {
    fs.mkdirSync(uploadsDirectory, { recursive: true });
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDirectory);
    },

    filename: function (req, file, cb) {
        const uniqueName =
            Date.now() +
            "-" +
            Math.round(Math.random() * 1e9);

        cb(
            null,
            uniqueName + path.extname(file.originalname)
        );
    }
});

const upload = multer({
    storage,
    limits: {
        fileSize: 10 * 1024 * 1024
    },
    fileFilter: function (req, file, cb) {
        const allowedExtensions = [
            ".pdf",
            ".jpg",
            ".jpeg",
            ".png"
        ];

        const extension =
            path.extname(file.originalname).toLowerCase();

        if (!allowedExtensions.includes(extension)) {
            return cb(
                new Error(
                    "Only PDF, JPG, JPEG and PNG certificates are allowed."
                )
            );
        }

        cb(null, true);
    }
});

// HOD: get all activities
router.get("/", requireHod, async (req, res) => {
    try {
        const activities = await Activity
            .find()
            .sort({
                createdAt: -1
            });

        res.json(activities);
    } catch (error) {
        res.status(500).json({
            message: "Error getting activities.",
            error: error.message
        });
    }
});

// Student: get only own activities
router.get("/my", requireStudent, async (req, res) => {
    try {
        const activities = await Activity
            .find({
                rollNumber: req.session.user.rollNumber
            })
            .sort({
                date: -1,
                createdAt: -1
            });

        res.json(activities);
    } catch (error) {
        res.status(500).json({
            message: "Error getting your activities.",
            error: error.message
        });
    }
});

// HOD: get activities for a selected student
router.get(
    "/student/:rollNumber",
    requireHod,
    async (req, res) => {
        try {
            const rollNumber = Number(req.params.rollNumber);

            if (!Number.isInteger(rollNumber)) {
                return res.status(400).json({
                    message: "Invalid roll number."
                });
            }

            const activities = await Activity
                .find({
                    rollNumber
                })
                .sort({
                    date: -1,
                    createdAt: -1
                });

            res.json(activities);
        } catch (error) {
            res.status(500).json({
                message: "Error getting student activities.",
                error: error.message
            });
        }
    }
);

// Student: add an activity.
//
// The roll number is taken from the logged-in session,
// not from the browser form.
router.post(
    "/",
    requireStudent,
    upload.single("certificate"),
    async (req, res) => {
        try {
            if (
                !req.body.activityName ||
                !req.body.eventName ||
                !req.body.collegeName ||
                !req.body.date
            ) {
                if (req.file) {
                    fs.unlink(req.file.path, () => {});
                }

                return res.status(400).json({
                    message: "Please fill all required fields."
                });
            }

            const activity = new Activity({
                rollNumber:
                    req.session.user.rollNumber,

                activityName:
                    req.body.activityName.trim(),

                eventName:
                    req.body.eventName.trim(),

                collegeName:
                    req.body.collegeName.trim(),

                date:
                    req.body.date,

                description:
                    (req.body.description || "").trim(),

                certificateFile:
                    req.file
                        ? "/uploads/" + req.file.filename
                        : null
            });

            const savedActivity =
                await activity.save();

            res.status(201).json({
                message: "Activity submitted successfully.",
                activity: savedActivity
            });
        } catch (error) {
            if (req.file) {
                fs.unlink(req.file.path, () => {});
            }

            console.error("Activity creation error:", error);

            res.status(500).json({
                message:
                    error.message ||
                    "Error adding activity."
            });
        }
    }
);

// Student: delete only their own activity
router.delete(
    "/:id",
    requireStudent,
    async (req, res) => {
        try {
            const activity =
                await Activity.findById(req.params.id);

            if (!activity) {
                return res.status(404).json({
                    message: "Activity record not found."
                });
            }

            if (
                Number(activity.rollNumber) !==
                Number(req.session.user.rollNumber)
            ) {
                return res.status(403).json({
                    message:
                        "You can delete only your own activity records."
                });
            }

            if (activity.certificateFile) {
                const relativePath =
                    activity.certificateFile.replace(
                        /^\/+/,
                        ""
                    );

                const filePath =
                    path.join(
                        __dirname,
                        "..",
                        relativePath
                    );

                if (fs.existsSync(filePath)) {
                    fs.unlinkSync(filePath);
                }
            }

            await Activity.findByIdAndDelete(
                req.params.id
            );

            res.json({
                message:
                    "Activity deleted successfully."
            });
        } catch (error) {
            console.error("Delete activity error:", error);

            res.status(500).json({
                message:
                    "Error deleting activity.",
                error: error.message
            });
        }
    }
);

module.exports = router;
