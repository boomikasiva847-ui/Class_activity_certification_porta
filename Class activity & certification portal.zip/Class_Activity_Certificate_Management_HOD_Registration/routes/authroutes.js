const express = require("express");
const bcrypt = require("bcryptjs");

const Student = require("../models/student");
const Hod = require("../models/hod");

const router = express.Router();

// Student registration.
//
// Existing preloaded students (1-59) can use this once to
// activate their account. New roll numbers can also register.
router.post("/register", async (req, res) => {
    try {
        const { rollNumber, name, email, password } = req.body;

        if (!rollNumber || !name || !password) {
            return res.status(400).json({
                message: "Roll number, name and password are required."
            });
        }

        if (String(password).length < 6) {
            return res.status(400).json({
                message: "Password must contain at least 6 characters."
            });
        }

        const roll = Number(rollNumber);

        if (!Number.isInteger(roll) || roll <= 0) {
            return res.status(400).json({
                message: "Please enter a valid roll number."
            });
        }

        const existingStudent = await Student.findOne({
            rollNumber: roll
        });

        if (existingStudent && existingStudent.passwordHash) {
            return res.status(409).json({
                message: "This student is already registered. Please login."
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        if (existingStudent) {
            // Activate an existing student record without deleting it.
            existingStudent.name = name.trim();
            existingStudent.email = (email || "").trim();
            existingStudent.passwordHash = passwordHash;

            await existingStudent.save();

            return res.status(201).json({
                message: "Account created successfully. You can now login."
            });
        }

        const newStudent = await Student.create({
            rollNumber: roll,
            name: name.trim(),
            email: (email || "").trim(),
            department: "B.Tech Information Technology",
            passwordHash
        });

        res.status(201).json({
            message: "Student registered successfully. You can now login.",
            student: {
                rollNumber: newStudent.rollNumber,
                name: newStudent.name
            }
        });
    } catch (error) {
        console.error("Registration error:", error);

        res.status(500).json({
            message: "Registration failed.",
            error: error.message
        });
    }
});

// Student login
router.post("/login", async (req, res) => {
    try {
        const { rollNumber, password } = req.body;

        if (!rollNumber || !password) {
            return res.status(400).json({
                message: "Roll number and password are required."
            });
        }

        const student = await Student.findOne({
            rollNumber: Number(rollNumber)
        });

        if (!student) {
            return res.status(401).json({
                message: "Student account not found. Please register first."
            });
        }

        if (!student.passwordHash) {
            return res.status(401).json({
                message: "This student is not registered yet. Please register first."
            });
        }

        const passwordMatch = await bcrypt.compare(
            password,
            student.passwordHash
        );

        if (!passwordMatch) {
            return res.status(401).json({
                message: "Incorrect password."
            });
        }

        req.session.user = {
            role: "student",
            id: student._id.toString(),
            rollNumber: student.rollNumber,
            name: student.name
        };

        res.json({
            message: "Login successful.",
            role: "student"
        });
    } catch (error) {
        console.error("Student login error:", error);

        res.status(500).json({
            message: "Login failed."
        });
    }
});

// HOD registration
router.post("/hod-register", async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                message: "Name, email and password are required."
            });
        }

        if (String(password).length < 6) {
            return res.status(400).json({
                message: "Password must contain at least 6 characters."
            });
        }

        const normalizedEmail = String(email).trim().toLowerCase();
        const existingHod = await Hod.findOne({ email: normalizedEmail });

        if (existingHod) {
            return res.status(409).json({
                message: "An HOD account with this email already exists. Please login."
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        const hod = await Hod.create({
            name: String(name).trim(),
            email: normalizedEmail,
            passwordHash
        });

        res.status(201).json({
            message: "HOD account created successfully. You can now login.",
            hod: {
                name: hod.name,
                email: hod.email
            }
        });
    } catch (error) {
        console.error("HOD registration error:", error);

        if (error.code === 11000) {
            return res.status(409).json({
                message: "An HOD account with this email already exists. Please login."
            });
        }

        res.status(500).json({
            message: "HOD registration failed."
        });
    }
});

// HOD login
router.post("/hod-login", async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                message: "HOD email and password are required."
            });
        }

        const normalizedEmail = String(email).trim().toLowerCase();
        const hod = await Hod.findOne({ email: normalizedEmail });

        if (!hod) {
            return res.status(401).json({
                message: "HOD account not found. Please register first."
            });
        }

        const passwordMatch = await bcrypt.compare(
            password,
            hod.passwordHash
        );

        if (!passwordMatch) {
            return res.status(401).json({
                message: "Incorrect password."
            });
        }

        req.session.user = {
            role: "hod",
            id: hod._id.toString(),
            email: hod.email,
            name: hod.name
        };

        res.json({
            message: "HOD login successful.",
            role: "hod"
        });
    } catch (error) {
        console.error("HOD login error:", error);

        res.status(500).json({
            message: "HOD login failed."
        });
    }
});

// Current logged-in user
router.get("/me", (req, res) => {
    if (!req.session || !req.session.user) {
        return res.status(401).json({
            message: "Not logged in."
        });
    }

    res.json({
        user: req.session.user
    });
});

// Logout
router.post("/logout", (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            console.error("Logout error:", error);

            return res.status(500).json({
                message: "Logout failed."
            });
        }

        res.clearCookie("connect.sid");

        res.json({
            message: "Logged out successfully."
        });
    });
});

module.exports = router;
