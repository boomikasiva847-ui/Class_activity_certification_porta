const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const session = require("express-session");
const path = require("path");

const studentRoutes =
    require("./routes/studentroutes");

const activityRoutes =
    require("./routes/activityroutes");

const authRoutes =
    require("./routes/authroutes");

const app = express();

const PORT = 5000;

// Middleware
app.use(cors({
    origin: "http://localhost:5000",
    credentials: true
}));

app.use(express.json());

app.use(
    express.urlencoded({
        extended: true
    })
);

// Session authentication
app.use(
    session({
        secret:
            "change-this-college-portal-session-secret",

        resave: false,

        saveUninitialized: false,

        cookie: {
            httpOnly: true,
            sameSite: "lax",
            secure: false,
            maxAge: 1000 * 60 * 60 * 8
        }
    })
);

// Static frontend
app.use(
    express.static(
        path.join(__dirname, "public")
    )
);

// Certificate files
app.use(
    "/uploads",
    express.static(
        path.join(__dirname, "uploads")
    )
);

// MongoDB connection
mongoose
    .connect(
        "mongodb://127.0.0.1:27017/certificate_portal"
    )
    .then(() => {
        console.log(
            "MongoDB connected successfully"
        );
    })
    .catch((error) => {
        console.log(
            "MongoDB connection error:",
            error.message
        );
    });

// API routes
app.use(
    "/auth",
    authRoutes
);

app.use(
    "/students",
    studentRoutes
);

app.use(
    "/activities",
    activityRoutes
);

// Home page
app.get("/", (req, res) => {
    res.sendFile(
        path.join(
            __dirname,
            "public",
            "index.html"
        )
    );
});

// Error handler
app.use((error, req, res, next) => {
    console.error(error);

    res.status(500).json({
        message:
            error.message ||
            "Something went wrong."
    });
});

app.listen(
    PORT,
    () => {
        console.log(
            `Server running at http://localhost:${PORT}`
        );
    }
);
