function requireLogin(req, res, next) {
    if (!req.session || !req.session.user) {
        return res.status(401).json({
            message: "Please login first."
        });
    }

    next();
}

function requireStudent(req, res, next) {
    if (
        !req.session ||
        !req.session.user ||
        req.session.user.role !== "student"
    ) {
        return res.status(403).json({
            message: "Student access required."
        });
    }

    next();
}

function requireHod(req, res, next) {
    if (
        !req.session ||
        !req.session.user ||
        req.session.user.role !== "hod"
    ) {
        return res.status(403).json({
            message: "HOD access required."
        });
    }

    next();
}

module.exports = {
    requireLogin,
    requireStudent,
    requireHod
};
