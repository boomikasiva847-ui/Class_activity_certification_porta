const mongoose = require("mongoose");

const activitySchema = new mongoose.Schema({
    rollNumber: {
        type: Number,
        required: true
    },

    activityName: {
        type: String,
        required: true
    },

    eventName: {
        type: String,
        required: true
    },

    collegeName: {
        type: String,
        required: true
    },

    date: {
        type: Date,
        required: true
    },

    description: {
        type: String
    },

    certificateFile: {
        type: String
    },

    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Activity", activitySchema);