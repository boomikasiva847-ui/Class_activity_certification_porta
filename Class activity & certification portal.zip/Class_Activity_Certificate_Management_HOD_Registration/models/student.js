const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
    rollNumber: {
        type: Number,
        required: true,
        unique: true
    },

    name: {
        type: String,
        required: true
    },

    department: {
        type: String,
        default: "B.Tech Information Technology"
    },

    email: {
        type: String,
        default: ""
    },

    passwordHash: {
        type: String,
        default: null
    },

    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Student", studentSchema);
